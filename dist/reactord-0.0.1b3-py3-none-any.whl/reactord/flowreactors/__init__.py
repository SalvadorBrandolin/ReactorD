"""Flowreactor module."""
from reactord.flowreactors import stationary_1d

__all__ = ["stationary_1d"]
