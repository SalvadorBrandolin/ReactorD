"""Stationary one dimension module."""
from reactord.flowreactors.stationary_1d import pfr

__all__ = ["pfr"]
